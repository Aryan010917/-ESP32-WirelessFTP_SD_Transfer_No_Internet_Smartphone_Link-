🔷 Project Title:
ESP32 FTP Server with SD Card and LED Indicators

This describes what the project does: sets up an FTP server on an ESP32 board using a microSD card, and uses LED indicators as part of the hardware.

📌 Overview:
The ESP32 is configured in Access Point (AP) mode, meaning it creates its own Wi-Fi network. Devices can connect to this network and communicate with the ESP32 using FTP to upload/download files stored on the SD card.

🔧 Circuit Components:
These are the parts you need:

ESP32 board

SD Card Module

Red and Green LEDs (with resistors)

Capacitor (for voltage stability)

Jumper wires, breadboard

5V power supply

🖼 Circuit Diagram:
The file Circuit diagram.jpg shows the exact wiring between components.

🔌 Connections:
SD Card Module to ESP32:

SD Card Pin	ESP32 Pin
GND	GND
+5V	5V
MOSI	D23
MISO	D19
SCK	D18
CS	D5

LEDs:

Red LED anode → Resistor → D26

Green LED anode → Resistor → D27

Both cathodes → GND

📚 Required Libraries:
You need these libraries installed in the Arduino IDE:

WiFi.h – for networking (comes with ESP32 board support)

SD.h – to work with microSD cards (also comes with ESP32 board support)

FTPServer.h – third-party library for FTP.
🔗 You must download from: FTPServer GitHub Repo

🚀 How to Use:
Upload the code to your ESP32 using Arduino IDE.

On your phone or PC, search for a Wi-Fi network:

SSID: ESP32_AP

Password: 12345678

Open an FTP client (like FileZilla) and connect to:

IP: 192.168.4.1

Username: esp32

Password: 12345

You can now upload or download files to/from the SD card via FTP.

